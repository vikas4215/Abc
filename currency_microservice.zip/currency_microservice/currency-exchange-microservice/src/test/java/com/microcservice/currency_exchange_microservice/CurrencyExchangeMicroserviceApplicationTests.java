package com.microcservice.currency_exchange_microservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CurrencyExchangeMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
