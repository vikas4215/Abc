insert into currency_exchange (id,cfrom,cto,conversion_multiple,environment) values(10001,'USD','INR',65,'');
insert into currency_exchange (id,cfrom,cto,conversion_multiple,environment) values(10002,'EUR','INR',75,'');
insert into currency_exchange (id,cfrom,cto,conversion_multiple,environment) values(10003,'AUD','INR',25,'');