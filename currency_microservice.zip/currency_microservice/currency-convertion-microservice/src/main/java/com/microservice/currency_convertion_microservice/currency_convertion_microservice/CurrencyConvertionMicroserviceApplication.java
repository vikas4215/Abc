package com.microservice.currency_convertion_microservice.currency_convertion_microservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableFeignClients
public class CurrencyConvertionMicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CurrencyConvertionMicroserviceApplication.class, args);
	}

}
