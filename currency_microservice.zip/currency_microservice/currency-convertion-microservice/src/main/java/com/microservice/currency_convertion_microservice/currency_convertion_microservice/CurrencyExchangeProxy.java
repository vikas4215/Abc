package com.microservice.currency_convertion_microservice.currency_convertion_microservice;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "currency-exchange-microservice", url="localhost:8000")
public interface CurrencyExchangeProxy {

    @GetMapping("/currency-exchange/from/{cfrom}/to/{cto}")
    public CurrencyConvertion retrieveExchangeValue(
            @PathVariable String cfrom,
            @PathVariable String cto);
}
