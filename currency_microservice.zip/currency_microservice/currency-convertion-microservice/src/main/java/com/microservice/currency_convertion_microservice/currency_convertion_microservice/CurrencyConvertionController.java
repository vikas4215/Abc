package com.microservice.currency_convertion_microservice.currency_convertion_microservice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
import java.util.HashMap;

@Controller
@RestController
public class CurrencyConvertionController
{
    @Autowired
    private CurrencyExchangeProxy proxy;

    @GetMapping("/currency-conversion-feign/from/{cfrom}/to/{cto}/quantity/{quantity}")
    public CurrencyConvertion convetionCalculation(@PathVariable String cfrom,
                                                   @PathVariable String cto,
                                                   @PathVariable BigDecimal quantity)
    {
//        HashMap<String,String> uriVeriable = new HashMap<>();
//        uriVeriable.put("cfrom",cfrom);
//        uriVeriable.put("cto",cto);
//        ResponseEntity<CurrencyConvertion> currencyConvertion = new
//                RestTemplate().getForEntity("http://localhost:8000/currency-exchange/from/{cfrom}/to/{cto}",CurrencyConvertion.class,uriVeriable);
//        CurrencyConvertion curr = currencyConvertion.getBody();

        CurrencyConvertion curr = proxy.retrieveExchangeValue(cfrom,cto);
        return new CurrencyConvertion(curr.getId(),cfrom,cto,quantity, curr.getConversionMultiple(), quantity.multiply(curr.getConversionMultiple()),"");
    }
}
