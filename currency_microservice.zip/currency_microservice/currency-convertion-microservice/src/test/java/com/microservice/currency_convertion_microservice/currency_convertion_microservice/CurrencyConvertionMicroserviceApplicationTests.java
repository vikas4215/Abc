package com.microservice.currency_convertion_microservice.currency_convertion_microservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CurrencyConvertionMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
