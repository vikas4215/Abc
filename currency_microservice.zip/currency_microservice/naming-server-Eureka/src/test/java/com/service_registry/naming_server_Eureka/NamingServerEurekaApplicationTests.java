package com.service_registry.naming_server_Eureka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NamingServerEurekaApplicationTests {

	@Test
	void contextLoads() {
	}

}
